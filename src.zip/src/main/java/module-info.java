module org.example.tugas83 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens org.example.tugas83 to javafx.fxml;
    exports org.example.tugas83;
}