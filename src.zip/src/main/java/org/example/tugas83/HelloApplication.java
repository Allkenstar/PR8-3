package org.example.tugas83;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

public class HelloApplication extends Application {

    private static final String DB_URL = "jdbc:postgresql://localhost:5432/PR8-3";
    private static final String USER = "postgres";
    private static final String PASS = "4l1k3n5t4r";

    @Override
    public void start(Stage primaryStage) throws Exception {
        TableView<Employee> table = createEmployeeTable();
        TableView<CommissionReport> reportTable = createCommissionReportTable();

        VBox root = new VBox(10, table, reportTable);
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Employee & Commission Report");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private TableView<Employee> createEmployeeTable() {
        TableView<Employee> table = new TableView<>();
        ObservableList<Employee> data = FXCollections.observableArrayList();

        TableColumn<Employee, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Employee, String> firstNameCol = new TableColumn<>("First Name");
        firstNameCol.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<Employee, String> lastNameCol = new TableColumn<>("Last Name");
        lastNameCol.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<Employee, Double> salaryCol = new TableColumn<>("Salary");
        salaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));

        TableColumn<Employee, Integer> deptCol = new TableColumn<>("Dept ID");
        deptCol.setCellValueFactory(new PropertyValueFactory<>("deptId"));

        table.getColumns().addAll(idCol, firstNameCol, lastNameCol, salaryCol, deptCol);

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT employee_id, first_name, last_name, salary, department_id FROM employees")) {

            while (rs.next()) {
                data.add(new Employee(
                        rs.getInt("employee_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getDouble("salary"),
                        rs.getInt("department_id")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        table.setItems(data);
        return table;
    }

    private TableView<CommissionReport> createCommissionReportTable() {
        TableView<CommissionReport> table = new TableView<>();
        ObservableList<CommissionReport> data = FXCollections.observableArrayList();

        TableColumn<CommissionReport, String> nameCol = new TableColumn<>("Full Name");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("fullName"));

        TableColumn<CommissionReport, Double> salaryCol = new TableColumn<>("Salary");
        salaryCol.setCellValueFactory(new PropertyValueFactory<>("salary"));

        TableColumn<CommissionReport, Double> pctCol = new TableColumn<>("Commission %");
        pctCol.setCellValueFactory(new PropertyValueFactory<>("percent"));

        TableColumn<CommissionReport, Double> komisiCol = new TableColumn<>("Commission");
        komisiCol.setCellValueFactory(new PropertyValueFactory<>("commission"));

        TableColumn<CommissionReport, Double> totalCol = new TableColumn<>("Total Salary");
        totalCol.setCellValueFactory(new PropertyValueFactory<>("total"));

        table.getColumns().addAll(nameCol, salaryCol, pctCol, komisiCol, totalCol);

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                     "SELECT first_name || ' ' || last_name AS full_name, salary, commission_pct, " +
                             "salary * commission_pct AS komisi, salary + (salary * commission_pct) AS total_salary FROM employees")) {

            while (rs.next()) {
                data.add(new CommissionReport(
                        rs.getString("full_name"),
                        rs.getDouble("salary"),
                        rs.getDouble("commission_pct"),
                        rs.getDouble("komisi"),
                        rs.getDouble("total_salary")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        table.setItems(data);
        return table;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
