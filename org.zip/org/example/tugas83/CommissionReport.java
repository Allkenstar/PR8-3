package org.example.tugas83;

public class CommissionReport {
    private String fullName;
    private double salary;
    private double percent;
    private double commission;
    private double total;

    public CommissionReport(String fullName, double salary, double percent, double commission, double total) {
        this.fullName = fullName;
        this.salary = salary;
        this.percent = percent;
        this.commission = commission;
        this.total = total;
    }

    public String getFullName() {
        return fullName;
    }

    public double getSalary() {
        return salary;
    }

    public double getPercent() {
        return percent;
    }

    public double getCommission() {
        return commission;
    }

    public double getTotal() {
        return total;
    }
}
